function s=boxcar(w)
%  boxcar(w) = Rectangular function of width w
%  T. C. O'Haver, 1988.
s=ones(1,w);